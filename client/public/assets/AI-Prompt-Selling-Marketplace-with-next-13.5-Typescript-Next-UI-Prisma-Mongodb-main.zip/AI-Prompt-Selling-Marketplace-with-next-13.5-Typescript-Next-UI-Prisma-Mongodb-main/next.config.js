/** @type {import('next').NextConfig} */
const nextConfig = {
    images: {
        domains: ["pixner.net"],
      },
}

module.exports = nextConfig
